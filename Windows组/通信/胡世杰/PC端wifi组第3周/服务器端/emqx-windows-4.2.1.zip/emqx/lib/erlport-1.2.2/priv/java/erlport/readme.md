# erlport.jar

## Design

## Build

```bash
mvn clean
mvn package
```
Package at path:`target/erlport-{Version}.jar`

## APIs
